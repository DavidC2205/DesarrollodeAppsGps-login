package com.example.adrian_jadid_desarrollo_de_apps_act_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView Nombre = (TextView) findViewById(R.id.Nombre);
        TextView Contraseña = (TextView) findViewById(R.id.Contraseña);


        Button loginbutton = (MaterialButton) findViewById(R.id.loginbutton);

        //administrador y administrador

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Nombre.getText().toString().equals("administrador") && Contraseña.getText().toString().equals("administrador")){
                    //correcto
                    Toast.makeText(MainActivity.this,"Logeado Correctamente",Toast.LENGTH_SHORT).show();
                    // Iniciar la nueva actividad (OtraPaginaActivity)
                    Intent intent = new Intent(MainActivity.this, OtraPaginaActivity.class);
                    startActivity(intent);

                }else
                    //incorrecto
                    Toast.makeText(MainActivity.this,"Logeado Incorrectamente !!!",Toast.LENGTH_SHORT).show();
            }
        });


    }
}
